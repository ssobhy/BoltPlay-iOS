//
//  IBPContentType.h
//  BoltPlay
//
//  Created by inmobly on 10/2/16.
//  Copyright © 2016 Inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, IBPContentType)
{
    IBP_CONTENT_TYPE_SINGLE_FILE = 0,
    IBP_CONTENT_TYPE_HLS = 1,
    IBP_CONTENT_TYPE_DASH = 2,
    IBP_CONTENT_TYPE_NOT_SUPPORTED = -1,
    IBP_CONTENT_TYPE_UNKNOWN = -2
};

@interface IBPContentTypeUtils : NSObject

+ (BOOL)isSupported:(IBPContentType) contentType;

@end
 
