//
//  IBPContentType.h
//  BoltPlay
//
//  Created by inmobly on 10/2/16.
//  Copyright © 2016 Inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, IBPContentType)
{
    IBP_CONTENT_TYPE_SINGLE_FILE = 0,
    IBP_CONTENT_TYPE_HLS = 1,
    IBP_CONTENT_TYPE_DASH = 2,
    IBP_CONTENT_TYPE_HLS_LIVE = 3,
    IBP_CONTENT_TYPE_NOT_SUPPORTED = -1,
    IBP_CONTENT_TYPE_UNKNOWN = -2
};

typedef NS_ENUM(NSInteger, IBPDownloadConnectivityType) {
    IBP_DOWNLOAD_CONNECTIVITY_WIFI = 1,
    IBP_DOWNLOAD_CONNECTIVITY_MOBILE_DATA = 2,
    IBP_DOWNLOAD_CONNECTIVITY_ANY= 3
};


@interface IBPContentTypeUtils : NSObject

+ (BOOL)isSupported:(IBPContentType) contentType;

@end
 
