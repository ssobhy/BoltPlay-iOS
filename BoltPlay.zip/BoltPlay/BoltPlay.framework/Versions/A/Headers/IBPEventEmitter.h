//
//  IBPEventEmitter.h
//  BoltPlay
//
//  Copyright © 2016 Inmobly. All rights reserved.

#import <Foundation/Foundation.h>
#import "IBPEventListener.h"
#import "IBPEventType.h"

@interface IBPEventEmitter : NSObject

+ (IBPEventEmitter *)sharedInstance;

/**
 * Adds a listener to the event queue.
 * <b>NOTE:</b> All the listeners are sent in the background thread
 *
 * @param eventType {@link IBPEventType}
 * @param listener {@link IBPEventListener}
 */
- (void)addListenerWithType:(NSString *)eventType listener:(__weak id<IBPEventListener>)listener;

/**
 * Adds a listener to the list of events to the event queue.
 * <b>NOTE:</b> All the listeners are sent in the background thread
 *
 * @param eventTypes List of event types {@link IBPEventType}
 * @param listener {@link IBPEventListener}
 */
- (void)addListenerWithEventList:(NSArray<NSString *> *)eventTypes listener:(__weak id<IBPEventListener>)listener;

/**
 * Remove a listener from listening to an specific events
 *
 * @param eventType {@link IBPEventType}
 * @param listener {@link IBPEventListener}
 */
- (void)removeListenerWithType:(NSString *)eventType listener:(__weak id<IBPEventListener>)listener;

/**
 * Remove a listener from listening to all event
 *
 * @param listener {@link IBPEventListener}
 */
- (void)removeListener:(__weak id<IBPEventListener>)listener;

- (void)removeAllListeners;

/**
 * Emits an event to all the listening threads.
 *
 * @param event {@link IBPEvent}
 */
- (void)emitEvent:(IBPEvent *)event;

@end
