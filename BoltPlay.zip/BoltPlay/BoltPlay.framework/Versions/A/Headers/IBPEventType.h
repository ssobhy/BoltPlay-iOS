//
//  IBPEventType.h
//  BoltPlay
//
//  Copyright © 2016 Inmobly. All rights reserved.

#import <Foundation/Foundation.h>

@interface IBPEventType : NSObject

+ (nonnull NSString *)ADD_DOWNLOAD_SUCCEEDED;
+ (nonnull NSString *)ADD_DOWNLOAD_FAILED;

+ (nonnull NSString *)DOWNLOAD_STARTED;
+ (nonnull NSString *)DOWNLOAD_PROGRESS;
+ (nonnull NSString *)DOWNLOAD_SUCCEEDED;
+ (nonnull NSString *)DOWNLOAD_CANCELED;

+ (nonnull NSString *)DOWNLOAD_FAILED;
+ (nonnull NSString *)DOWNLOAD_FAILED_AND_WILL_RETRY;

+ (nonnull NSString *)DELETION_SUCCEEDED;
+ (nonnull NSString *)DELETION_FAILED;
+ (nonnull NSString *)ITEM_ALREADY_DOWNLOADED;
+ (nonnull NSString *)AUTHORIZATION_ERROR;
+ (nonnull NSString *)SINGLE_DASH_ITEM_DOWNLOAD_SUCCEEDED ;

+ (nonnull NSArray<NSString *> *)ALL;

@end
