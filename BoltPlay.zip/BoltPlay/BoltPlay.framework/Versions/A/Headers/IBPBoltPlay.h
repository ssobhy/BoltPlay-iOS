//
//  IBPBoltPlay.h
//  BoltPlay
//
//  Copyright © 2016 Inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IBPContentTypeUtils.h"
#import "IBPEventEmitter.h"
#import <UIKit/UIKit.h>

@interface IBPBoltPlayBuilder : NSObject

@property(nonatomic) NSString *contentId;
@property(nonatomic) NSString *file;
@property(nonatomic) IBPContentType contentType;
@property(nonatomic) NSString *title;
@property(nonatomic) NSString *desc;
@property(nonatomic) NSInteger duration;
@property(nonatomic) NSArray<NSString *> *keywords;
@property(nonatomic) BOOL neglectOffPeakConfig;
@property(nonatomic) NSDate *executionDate;
@property(nonatomic) IBPDownloadConnectivityType downloadConnectivityType;
@property (nonatomic) NSInteger downloadPercent;

@end

@interface IBPBoltPlay : NSObject

+ (instancetype) boltPlayWithBlock:(void (^)(IBPBoltPlayBuilder *))updateBlock;

- (NSString*) load;

- (void) download;

- (void) deleteContent;

- (BOOL) isDownloaded;

- (BOOL) isDownloading;

- (void) reportStartPlay;
    
- (void) reportFinishedPlayingWithPercent:(float)watchedPercent  andBufferedPercent:(float)bufferedPercent;

- (void) rateContentWithOldRate:(float)oldRate newRate:(float)newRate;

+ (IBPEventEmitter*) eventEmitter;

+ (NSArray<NSString*>*) getDownloadedContentIds;

+ (NSArray<NSString*>*) getDownloadingQueueContentIds; //w

@end
