//
//  IBPEventContentItem.h
//  BoltPlay
//
//  Copyright © 2016 Inmobly. All rights reserved.

#import "IBPEventItem.h"

@interface IBPEventContentItem : IBPEventItem

@property (readonly) NSString *contentId;
@property (readonly) NSString *url;

- (instancetype)initWithContentId:(NSString *)contentId url:(NSString *)url;

@end
