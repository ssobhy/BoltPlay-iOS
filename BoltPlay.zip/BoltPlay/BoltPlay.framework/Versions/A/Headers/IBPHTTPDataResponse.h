#import <Foundation/Foundation.h>
#import "IBPHTTPResponse.h"


@interface IBPHTTPDataResponse : NSObject <IBPHTTPResponse>
{
	NSUInteger offset;
	NSData *data;
}

- (id)initWithData:(NSData *)data;

@end
