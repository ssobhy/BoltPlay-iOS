//
//  IBPEventContentItemProgress.h
//  BoltPlay
//
//  Copyright © 2016 Inmobly. All rights reserved.

#import "IBPEventContentItem.h"

@interface IBPEventContentItemProgress : IBPEventContentItem

@property (readonly) NSInteger progress;

- (instancetype)initWithContentId:(NSString *)contentId url:(NSString *)url progress:(NSInteger)progress;

@end
