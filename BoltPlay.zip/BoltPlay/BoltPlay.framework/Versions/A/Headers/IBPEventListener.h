//
//  IBPEventListener.h
//  BoltPlay
//
//  Copyright © 2016 Inmobly. All rights reserved.

#import <Foundation/Foundation.h>
#import "IBPEvent.h"

@protocol IBPEventListener <NSObject>

@required
- (void)handleEvent:(IBPEvent *)event;

@end
